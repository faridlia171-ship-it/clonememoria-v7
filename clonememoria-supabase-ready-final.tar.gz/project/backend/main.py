import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.core.config import settings
from backend.core.logging_config import setup_logging
from backend.api.middleware import RequestLoggingMiddleware
from backend.api.routes import auth, clones, memories, conversations, documents, chat, health, api_keys, admin


setup_logging(log_level=settings.LOG_LEVEL, log_format=settings.LOG_FORMAT)

logger = logging.getLogger(__name__)
logger.info("MAIN_MODULE_LOADED", extra={"file": __file__})


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    logger.info("APPLICATION_STARTUP", extra={
        "project_name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "llm_provider": settings.LLM_PROVIDER
    })

    yield

    logger.info("APPLICATION_SHUTDOWN")


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan
)

app.add_middleware(RequestLoggingMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

logger.info("CORS_MIDDLEWARE_CONFIGURED", extra={
    "allowed_origins": settings.CORS_ORIGINS
})

app.include_router(
    auth.router,
    prefix=f"{settings.API_V1_PREFIX}/auth",
    tags=["auth"]
)

app.include_router(
    clones.router,
    prefix=f"{settings.API_V1_PREFIX}/clones",
    tags=["clones"]
)

app.include_router(
    memories.router,
    prefix=f"{settings.API_V1_PREFIX}/clones/{{clone_id}}/memories",
    tags=["memories"]
)

app.include_router(
    conversations.router,
    prefix=f"{settings.API_V1_PREFIX}/clones/{{clone_id}}/conversations",
    tags=["conversations"]
)

app.include_router(
    documents.router,
    prefix=f"{settings.API_V1_PREFIX}/clones/{{clone_id}}/documents",
    tags=["documents"]
)

app.include_router(
    chat.router,
    prefix=f"{settings.API_V1_PREFIX}/chat",
    tags=["chat"]
)

app.include_router(
    health.router,
    tags=["health"]
)

app.include_router(
    api_keys.router,
    prefix=f"{settings.API_V1_PREFIX}",
    tags=["api-keys"]
)

app.include_router(
    admin.router,
    prefix=f"{settings.API_V1_PREFIX}",
    tags=["admin"]
)

logger.info("API_ROUTES_REGISTERED", extra={
    "api_prefix": settings.API_V1_PREFIX
})


@app.get("/")
async def root():
    """Root endpoint."""
    logger.debug("ROOT_ENDPOINT_ACCESSED")
    return {
        "message": f"Welcome to {settings.PROJECT_NAME}",
        "version": settings.VERSION,
        "docs": "/docs"
    }


if __name__ == "__main__":
    import uvicorn

    logger.info("STARTING_UVICORN_SERVER", extra={
        "host": "0.0.0.0",
        "port": 8000
    })

    uvicorn.run(
        "backend.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_config=None
    )
